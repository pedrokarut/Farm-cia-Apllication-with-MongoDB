package classes;

import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.types.ObjectId;


public class Medicamento 
{
    private ObjectId id_medicamento;
    private String descricao;
    private String Nome;
    private double valor;

    public Medicamento() {}
    
    

    
//    public void Medicamento(String nome)
//        {
//         
//         
//            
//         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
//         // Now connect to your databases
//         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
//         System.out.println("Conexao ok");           
//         MongoCollection<Document> coll = db.getCollection("Medicamento");   
//         
//         BasicDBObject query =  new BasicDBObject();
//         query.put("nome", nome);
//         
//         FindIterable<Document> cursor = coll.find(query);
//         
//         
//                  
//         cursor.forEach(new Block<Document>() 
//         {
//           @Override
//            public void apply(final Document document)
//            {                
//                m.setId_medicamento(document.getObjectId("_id"));
//                m.setDescricao(document.getString("descricao"));
//                m.setValor(document.getDouble("valor"));
//                m.setNome(document.getString("nome"));
//            }
//
//         });
//         
//        }   
//        

    public ObjectId getId_medicamento() {
        return id_medicamento;
    }

    public void setId_medicamento(ObjectId id_medicamento) {
        this.id_medicamento = id_medicamento;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Medicamento(String descricao, String Nome, double valor) {
        this.descricao = descricao;
        this.Nome = Nome;
        this.valor = valor;
    }
    
    
    
    
}
