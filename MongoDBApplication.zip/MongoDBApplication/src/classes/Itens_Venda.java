package classes;
import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.types.ObjectId;

public class Itens_Venda 
{
    private ObjectId id_item;    
    private String data;
    private int quantidade;
    private Medicamento cod_medicamento;
    private Venda cod_Venda;

    public Itens_Venda(String data, int quantidade, Medicamento cod_medicamento, Venda cod_Venda) {
        this.data = data;
        this.quantidade = quantidade;
        this.cod_medicamento = cod_medicamento;
        this.cod_Venda = cod_Venda;
    }
    final Medicamento m = new Medicamento();

    public Itens_Venda() {}
    
    
     public void InsertItem(String nomeMed, int qtd)
        {
         

         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
        
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         
         
         MongoCollection<Document> collItens = db.getCollection("Itens_Venda");            
         MongoCollection<Document> collVenda = db.getCollection("Venda");
         
         BasicDBObject query =  new BasicDBObject();
         query.put("nome", nomeMed);
         
         FindIterable<Document> cursor = db.getCollection("Medicamento").find(query);
                          
         cursor.forEach(new Block<Document>() 
         {
           @Override
            public void apply(final Document document)
            {                
                m.setId_medicamento(document.getObjectId("_id"));
                m.setDescricao(document.getString("descricao"));
                m.setValor(document.getDouble("valor"));
                m.setNome(document.getString("nome"));
            }
         });
         
         //Code to insert a Medicamento in the Itens_Venda's Collection
         db.getCollection("Itens_Venda").insertOne(new Document()
                                                   .append("quantidade", qtd)        
                                                   .append("Medicamento", new Document()
                                                                          .append("_id", m.getId_medicamento())
                                                                          .append("nome", m.getNome())
                                                                          .append("descricao", m.getDescricao())
                                                                          .append("valor", m.getValor()))
                                                   );         
         System.out.println("Item registrado!");
         
         
        }
     
     
     
     
     

    public ObjectId getId_item() {
        return id_item;
    }

    public void setId_item(ObjectId id_item) {
        this.id_item = id_item;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public Medicamento getCod_medicamento() {
        return cod_medicamento;
    }

    public void setCod_medicamento(Medicamento cod_medicamento) {
        this.cod_medicamento = cod_medicamento;
    }

    public Venda getCod_Venda() {
        return cod_Venda;
    }

    public void setCod_Venda(Venda cod_Venda) {
        this.cod_Venda = cod_Venda;
    }
    
    
    
}
