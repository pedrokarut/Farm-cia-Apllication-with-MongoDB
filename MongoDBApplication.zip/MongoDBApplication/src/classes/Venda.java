package classes;

import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.types.ObjectId;

public class Venda 
{
    private ObjectId id_venda;
    private Cliente id_cliente;
    private Funcionario id_funcionario;
    private String data;
    private double total;

    public Venda(Cliente id_cliente, Funcionario id_funcionario, String data, double total) {
        this.id_cliente = id_cliente;
        this.id_funcionario = id_funcionario;
        this.data = data;
        this.total = total;
    }
    
        Venda v;
        Cliente c;
        Funcionario f;

    public Venda() { }
    
        public  void InsertVenda(String nomeCli, String nomeFun, String data, Double total)
        {
         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );        
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");     
                   
         
         
         c = new Cliente();
         
         BasicDBObject queryCli =  new BasicDBObject();
         queryCli.put("nome", nomeCli);
         
         FindIterable<Document> cursorCli = db.getCollection("Clientes").find(queryCli);
                          
         cursorCli.forEach(new Block<Document>() 
         {
           @Override
            public void apply(final Document document)
            {                
                c.setId_cliente(document.getObjectId("_id"));
                c.setNome(document.getString("nome"));
                c.setIdade(document.getInteger("idade"));
                c.setCpf(document.getLong("cpf"));
            }
         });
         
         
         
         
        f = new Funcionario();
        BasicDBObject queryFun =  new BasicDBObject();
        queryFun.put("nome", nomeFun);
         
         FindIterable<Document> cursorFun = db.getCollection("Clientes").find(queryFun);
                          
         cursorFun.forEach(new Block<Document>() 
         {
           @Override
            public void apply(final Document document)
            {                
                f.setId_funcionario(document.getObjectId("_id"));
                f.setNome(document.getString("nome"));
                f.setIdade(document.getInteger("idade"));
                f.setCpf(document.getLong("cpf"));
            }
         });          
         
         
         
         db.getCollection("Venda").insertOne(                 
                 new Document()
                 .append("Data", data)
                 .append("total", total)
                 .append("Cliente", new Document()
                                    .append("_id", c.getId_cliente())  
                                    .append("nome", c.getNome())
                                    .append("cpf", c.getCpf())
                                    .append("idade", c.getIdade())
                        )
                 .append("Funcionario", new Document()
                                    .append("_id", f.getId_funcionario())
                                    .append("nome", f.getNome())
                                    .append("cpf", f.getCpf())
                                    .append("idade", f.getIdade())                        
                        )
         
         );
        }
        
        
        public  void SelectVenda(String data)
        {        
         
            
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         System.out.println("Conexao ok");           
         MongoCollection<Document> collVenda = db.getCollection("Venda");   
         
         BasicDBObject query =  new BasicDBObject();
         query.put("data", data);
         
         FindIterable<Document> cursor = collVenda.find(query);
         
         cursor.forEach(new Block<Document>() 
         {
           @Override
            public void apply(final Document document)
            {
               v.setData(document.getString("data"));
               v.setTotal(document.getDouble("total"));
               v.setId_cliente((Cliente) document.get("Cliente"));
               v.setId_funcionario((Funcionario) document.get("Funcionario"));
            }

         });
         
        }   
     
     
     

    public ObjectId getId_venda() {
        return id_venda;
    }

    public void setId_venda(ObjectId id_venda) {
        this.id_venda = id_venda;
    }

    public Cliente getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(Cliente id_cliente) {
        this.id_cliente = id_cliente;
    }

    public Funcionario getId_funcionario() {
        return id_funcionario;
    }

    public void setId_funcionario(Funcionario id_funcionario) {
        this.id_funcionario = id_funcionario;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    
    
}
