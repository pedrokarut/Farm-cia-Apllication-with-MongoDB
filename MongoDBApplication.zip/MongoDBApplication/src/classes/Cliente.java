package classes;
import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javax.swing.JOptionPane;
import org.bson.Document;
import org.bson.types.ObjectId;

public class Cliente 
{
    private ObjectId id_cliente;
    private String nome;
    private long cpf;
    private int idade;
    

    public Cliente(String nome, long cpf, int idade) {
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
    }    
    
    public Cliente() {}
    
    
        Cliente c;  
        
        
        
        
        
        
    
        public  void SelectCliente(String nome)
        {
                    
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         System.out.println("Conexao ok");           
         MongoCollection<Document> coll = db.getCollection("Medicamento");   
         
         BasicDBObject query =  new BasicDBObject();
         query.put("nome", nome);
         
         FindIterable<Document> cursor = coll.find(query);
         
         cursor.forEach(new Block<Document>() 
         {
           @Override
            public void apply(final Document document)
            {
               c.setCpf(document.getLong("cpf"));
               c.setNome(document.getString("nome"));
               c.setIdade(document.getInteger("idade"));
               c.setId_cliente(document.getObjectId("_id"));
            }

         });
         
        }   
 
         
    

    public ObjectId getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(ObjectId id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
    
    
    
    
    
}
