package classes;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import com.mongodb.WriteConcern;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.DBCursor;

import com.mongodb.ServerAddress;
import java.util.Arrays;import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import com.mongodb.WriteConcern;
import com.mongodb.Block;
import com.mongodb.CursorType;

import com.mongodb.ServerAddress;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.util.Arrays;
import javax.swing.JOptionPane;
import org.bson.Document;



public class conexao {
    
        Medicamento m;
    
	public  void InsertPessoa(String collection, String nome, long cpf, int idade)
        {             
         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );
			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         System.out.print("Conexao ok");         
            
            
         MongoCollection<Document> coll = db.getCollection(collection);            
         
         coll.insertOne(
                 
                 new Document()
                 .append("nome", nome)
                 .append("idade", idade)
                 .append("cpf", cpf)
                          
         );
         
         //end of Insert method
         }
        
        
        public  void UpdatePessoa(String nome, long cpf, long idade)
        {          
         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         System.out.println("Conexao ok");           
            
         BasicDBObject criterio = new BasicDBObject();
         criterio.put("nome", nome);
         
         BasicDBObject NovoDocumento = new BasicDBObject();
         NovoDocumento.put("nome", nome);
         NovoDocumento.put("cpf", cpf); 
         NovoDocumento.put("idade", idade);
         
         BasicDBObject updateDocumento = new BasicDBObject();
         updateDocumento.put("$set", NovoDocumento);       
         
         MongoCollection<Document> coll = db.getCollection("Clientes");   
         
         coll.updateOne(criterio, updateDocumento);            
         System.out.println("Update executado com sucesso!");   
            
        }
         
        
        public  void DeletePessoa(String nome)
        {
         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         System.out.println("Conexao ok");           
            
         MongoCollection<Document> coll = db.getCollection("Clientes");   
         coll.deleteOne(new Document("nome", nome));
         System.out.println("Delete OK!");
         
        }
         
        
        public  void SelectPessoa(String nome)
        {
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         System.out.println("Conexao ok");           
         MongoCollection<Document> coll = db.getCollection("Clientes");   
         
         BasicDBObject query =  new BasicDBObject();
         query.put("nome", nome);
         
         FindIterable<Document> cursor = coll.find(query);
         
         cursor.forEach(new Block<Document>() 
         {
           @Override
            public void apply(final Document document)
            {
                JOptionPane.showMessageDialog(null, document);
            }

         });
                 
        
        }
        
         
        
       
        public  void InsertMedicamento(String nome, double valor, String descricao)
        {
         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );
			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
            System.out.print("Conexao ok");
            
            
            
         MongoCollection<Document> coll = db.getCollection("Medicamento");            
         
         coll.insertOne(
                 
                 new Document()
                 .append("nome", nome)
                 .append("valor", valor)
                 .append("descricao", descricao)                
         
         );
         
        }
			
     
        public  void UpdateMedicamento(String nome, double valor, String descricao)
        {
         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         System.out.println("Conexao ok");           
            
         BasicDBObject criterio = new BasicDBObject();
         criterio.put("nome", nome);
         
         BasicDBObject NovoDocumento = new BasicDBObject();
         NovoDocumento.put("nome", nome);
         NovoDocumento.put("valor", valor);
         NovoDocumento.put("descricao", descricao); 
                  
         BasicDBObject updateDocumento = new BasicDBObject();
         updateDocumento.put("$set", NovoDocumento);       
         
         MongoCollection<Document> coll = db.getCollection("Medicamento");   
         
         coll.updateOne(criterio, updateDocumento);            
         System.out.println("Update executado com sucesso!");  
         
        }
      
      
        public  void DeleteMedicamento(String nome)
        {
          // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         System.out.println("Conexao ok");           
            
         MongoCollection<Document> coll = db.getCollection("Medicamento");   
         coll.deleteOne(new Document("nome", nome));
         System.out.println("Delete OK!");
         
        }
    
        
        
     
        
        public  void UpdateReceita(String nomeDoutor, String Descricao, long codCli)
        {
         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
         System.out.println("Conexao ok");           
            
         BasicDBObject criterio = new BasicDBObject();
         criterio.put("noemDoutor", nomeDoutor);
         
         BasicDBObject NovoDocumento = new BasicDBObject();
         NovoDocumento.put("nomeDoutor", nomeDoutor);
         NovoDocumento.put("descricao", Descricao);
         NovoDocumento.put("Código_do_Cliente", codCli); 
                  
         BasicDBObject updateDocumento = new BasicDBObject();
         updateDocumento.put("$set", NovoDocumento);       
         
         MongoCollection<Document> coll = db.getCollection("Receita");   
         
         coll.updateOne(criterio, updateDocumento);            
         System.out.println("Update executado com sucesso!");  
        }
        
        public static void DeleteReceita(String descricao)
        {
         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");                  
            
         MongoCollection<Document> coll = db.getCollection("Receita");   
         coll.deleteOne(new Document("descricao", descricao));
         System.out.println("Delete OK!");
        }
        
        
        
       
        
        
       
        
       
        
        
}
