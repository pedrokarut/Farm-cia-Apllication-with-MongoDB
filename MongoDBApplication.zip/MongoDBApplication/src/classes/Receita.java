package classes;

import com.mongodb.BasicDBObject;
import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.types.ObjectId;

public class Receita 
{
    private ObjectId id_receita;
    private String descricao;
    private String nome_doutor;
    private Cliente id_cliente;
        
  
    Cliente c;

    public Receita() { }
    
       public  void InsertReceita(String nomeDoutor, String Descricao, String nomeCli)
        {
         // To connect to mongodb server
         MongoClient mongoClient = new MongoClient( "localhost" , 27017 );
			
         // Now connect to your databases
         MongoDatabase db = mongoClient.getDatabase("Pedrodb");
            System.out.print("Conexao ok");
            
         c =  new Cliente();            
         BasicDBObject query =  new BasicDBObject();
         query.put("nome", nomeCli);
         
         FindIterable<Document> cursor = db.getCollection("Clientes").find(query);
         
         cursor.forEach(new Block<Document>() 
         {
           @Override
            public void apply(final Document document)
            {
               c.setCpf(document.getLong("cpf"));
               c.setNome(document.getString("nome"));
               c.setIdade(Integer.parseInt(document.get("idade").toString()));
               c.setId_cliente(document.getObjectId("_id"));
            }

         });     
            
         
         db.getCollection("Receita").insertOne(
                 
                 new Document()
                 .append("nomeDoutor", nomeDoutor)
                 .append("descricao", Descricao)
                 .append("Cliente", new Document()
                                    .append("_id", c.getId_cliente())
                                    .append("nome", c.getNome())
                                    .append("idade", c.getIdade())
                                    .append("cpf", c.getCpf()) 
                        )                
         
         );
         
            System.out.println("Receita registrada!");
         
        }

    public Receita(String descricao, String nome_doutor, Cliente id_cliente) {
        this.descricao = descricao;
        this.nome_doutor = nome_doutor;
        this.id_cliente = id_cliente;
    }
    
    

    public ObjectId getId_receita() {
        return id_receita;
    }

    public void setId_receita(ObjectId id_receita) {
        this.id_receita = id_receita;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNome_doutor() {
        return nome_doutor;
    }

    public void setNome_doutor(String nome_doutor) {
        this.nome_doutor = nome_doutor;
    }

    public Cliente getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(Cliente id_cliente) {
        this.id_cliente = id_cliente;
    }
       
       
       
    
}
